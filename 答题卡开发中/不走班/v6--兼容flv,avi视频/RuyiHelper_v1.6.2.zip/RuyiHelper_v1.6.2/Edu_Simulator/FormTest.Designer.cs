﻿namespace Edu_Simulator
{
    partial class FormTest
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl_main = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button_CompetitivePPT = new System.Windows.Forms.Button();
            this.button_xitiPPT = new System.Windows.Forms.Button();
            this.button_Competitive = new System.Windows.Forms.Button();
            this.button_xiti = new System.Windows.Forms.Button();
            this.button_ppt = new System.Windows.Forms.Button();
            this.button_callname = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox_coursename = new System.Windows.Forms.TextBox();
            this.textBox_name = new System.Windows.Forms.TextBox();
            this.textBox_lessonid = new System.Windows.Forms.TextBox();
            this.button_getlesson = new System.Windows.Forms.Button();
            this.textBox_classname = new System.Windows.Forms.TextBox();
            this.button_login = new System.Windows.Forms.Button();
            this.label_LessonID = new System.Windows.Forms.Label();
            this.comboBox_roomid = new System.Windows.Forms.ComboBox();
            this.comboBox_schoolid = new System.Windows.Forms.ComboBox();
            this.comboBox_lessonIndex = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.textBox_pwd = new System.Windows.Forms.TextBox();
            this.textBox_user = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.comboBox_ip = new System.Windows.Forms.ComboBox();
            this.textBoxLog = new System.Windows.Forms.TextBox();
            this.button_reward = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.button_hondover = new System.Windows.Forms.Button();
            this.button_handover_0 = new System.Windows.Forms.Button();
            this.button_handon = new System.Windows.Forms.Button();
            this.tabControl_main.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl_main
            // 
            this.tabControl_main.Controls.Add(this.tabPage2);
            this.tabControl_main.Controls.Add(this.tabPage1);
            this.tabControl_main.Location = new System.Drawing.Point(12, 12);
            this.tabControl_main.Name = "tabControl_main";
            this.tabControl_main.SelectedIndex = 0;
            this.tabControl_main.Size = new System.Drawing.Size(748, 426);
            this.tabControl_main.TabIndex = 0;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.button_CompetitivePPT);
            this.tabPage2.Controls.Add(this.button_xitiPPT);
            this.tabPage2.Controls.Add(this.button_Competitive);
            this.tabPage2.Controls.Add(this.button_xiti);
            this.tabPage2.Controls.Add(this.button_ppt);
            this.tabPage2.Controls.Add(this.button_callname);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.textBox_coursename);
            this.tabPage2.Controls.Add(this.textBox_name);
            this.tabPage2.Controls.Add(this.textBox_lessonid);
            this.tabPage2.Controls.Add(this.button_getlesson);
            this.tabPage2.Controls.Add(this.textBox_classname);
            this.tabPage2.Controls.Add(this.button_login);
            this.tabPage2.Controls.Add(this.label_LessonID);
            this.tabPage2.Controls.Add(this.comboBox_roomid);
            this.tabPage2.Controls.Add(this.comboBox_schoolid);
            this.tabPage2.Controls.Add(this.comboBox_lessonIndex);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Controls.Add(this.label5);
            this.tabPage2.Controls.Add(this.textBox_pwd);
            this.tabPage2.Controls.Add(this.textBox_user);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(740, 400);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "模拟";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button_CompetitivePPT
            // 
            this.button_CompetitivePPT.Location = new System.Drawing.Point(621, 205);
            this.button_CompetitivePPT.Name = "button_CompetitivePPT";
            this.button_CompetitivePPT.Size = new System.Drawing.Size(88, 38);
            this.button_CompetitivePPT.TabIndex = 27;
            this.button_CompetitivePPT.Text = "PPT抢答";
            this.button_CompetitivePPT.UseVisualStyleBackColor = true;
            this.button_CompetitivePPT.Click += new System.EventHandler(this.button_CompetitivePPT_Click);
            // 
            // button_xitiPPT
            // 
            this.button_xitiPPT.Location = new System.Drawing.Point(502, 205);
            this.button_xitiPPT.Name = "button_xitiPPT";
            this.button_xitiPPT.Size = new System.Drawing.Size(88, 38);
            this.button_xitiPPT.TabIndex = 26;
            this.button_xitiPPT.Text = "PPT做题";
            this.button_xitiPPT.UseVisualStyleBackColor = true;
            this.button_xitiPPT.Click += new System.EventHandler(this.button_xitiPPT_Click);
            // 
            // button_Competitive
            // 
            this.button_Competitive.Location = new System.Drawing.Point(377, 205);
            this.button_Competitive.Name = "button_Competitive";
            this.button_Competitive.Size = new System.Drawing.Size(88, 38);
            this.button_Competitive.TabIndex = 25;
            this.button_Competitive.Text = "抢答";
            this.button_Competitive.UseVisualStyleBackColor = true;
            this.button_Competitive.Click += new System.EventHandler(this.button_Competitive_Click);
            // 
            // button_xiti
            // 
            this.button_xiti.Location = new System.Drawing.Point(261, 205);
            this.button_xiti.Name = "button_xiti";
            this.button_xiti.Size = new System.Drawing.Size(88, 38);
            this.button_xiti.TabIndex = 24;
            this.button_xiti.Text = "做题";
            this.button_xiti.UseVisualStyleBackColor = true;
            this.button_xiti.Click += new System.EventHandler(this.button_xiti_Click);
            // 
            // button_ppt
            // 
            this.button_ppt.Location = new System.Drawing.Point(20, 205);
            this.button_ppt.Name = "button_ppt";
            this.button_ppt.Size = new System.Drawing.Size(88, 38);
            this.button_ppt.TabIndex = 23;
            this.button_ppt.Text = "打开PPT";
            this.button_ppt.UseVisualStyleBackColor = true;
            this.button_ppt.Click += new System.EventHandler(this.button_ppt_Click);
            // 
            // button_callname
            // 
            this.button_callname.Location = new System.Drawing.Point(138, 205);
            this.button_callname.Name = "button_callname";
            this.button_callname.Size = new System.Drawing.Size(88, 38);
            this.button_callname.TabIndex = 22;
            this.button_callname.Text = "点名";
            this.button_callname.UseVisualStyleBackColor = true;
            this.button_callname.Click += new System.EventHandler(this.button1_callname);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(375, 26);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(29, 12);
            this.label9.TabIndex = 21;
            this.label9.Text = "班级";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(375, 136);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 12);
            this.label8.TabIndex = 20;
            this.label8.Text = "科目";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(375, 84);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 12);
            this.label7.TabIndex = 19;
            this.label7.Text = "姓名";
            // 
            // textBox_coursename
            // 
            this.textBox_coursename.Location = new System.Drawing.Point(436, 132);
            this.textBox_coursename.Name = "textBox_coursename";
            this.textBox_coursename.Size = new System.Drawing.Size(100, 21);
            this.textBox_coursename.TabIndex = 18;
            // 
            // textBox_name
            // 
            this.textBox_name.Location = new System.Drawing.Point(436, 77);
            this.textBox_name.Name = "textBox_name";
            this.textBox_name.Size = new System.Drawing.Size(100, 21);
            this.textBox_name.TabIndex = 17;
            // 
            // textBox_lessonid
            // 
            this.textBox_lessonid.Location = new System.Drawing.Point(249, 132);
            this.textBox_lessonid.Name = "textBox_lessonid";
            this.textBox_lessonid.Size = new System.Drawing.Size(100, 21);
            this.textBox_lessonid.TabIndex = 16;
            // 
            // button_getlesson
            // 
            this.button_getlesson.Location = new System.Drawing.Point(569, 124);
            this.button_getlesson.Name = "button_getlesson";
            this.button_getlesson.Size = new System.Drawing.Size(140, 38);
            this.button_getlesson.TabIndex = 15;
            this.button_getlesson.Text = "上课";
            this.button_getlesson.UseVisualStyleBackColor = true;
            this.button_getlesson.Click += new System.EventHandler(this.button_getlesson_Click);
            // 
            // textBox_classname
            // 
            this.textBox_classname.Enabled = false;
            this.textBox_classname.Location = new System.Drawing.Point(436, 22);
            this.textBox_classname.Name = "textBox_classname";
            this.textBox_classname.Size = new System.Drawing.Size(100, 21);
            this.textBox_classname.TabIndex = 14;
            // 
            // button_login
            // 
            this.button_login.Location = new System.Drawing.Point(569, 68);
            this.button_login.Name = "button_login";
            this.button_login.Size = new System.Drawing.Size(140, 38);
            this.button_login.TabIndex = 13;
            this.button_login.Text = "登陆";
            this.button_login.UseVisualStyleBackColor = true;
            this.button_login.Click += new System.EventHandler(this.button1_Click);
            // 
            // label_LessonID
            // 
            this.label_LessonID.AutoSize = true;
            this.label_LessonID.Location = new System.Drawing.Point(185, 137);
            this.label_LessonID.Name = "label_LessonID";
            this.label_LessonID.Size = new System.Drawing.Size(53, 12);
            this.label_LessonID.TabIndex = 12;
            this.label_LessonID.Text = "LessonID";
            // 
            // comboBox_roomid
            // 
            this.comboBox_roomid.Enabled = false;
            this.comboBox_roomid.FormattingEnabled = true;
            this.comboBox_roomid.Location = new System.Drawing.Point(249, 23);
            this.comboBox_roomid.Name = "comboBox_roomid";
            this.comboBox_roomid.Size = new System.Drawing.Size(100, 20);
            this.comboBox_roomid.TabIndex = 11;
            this.comboBox_roomid.SelectedIndexChanged += new System.EventHandler(this.comboBox_roomid_SelectedIndexChanged);
            // 
            // comboBox_schoolid
            // 
            this.comboBox_schoolid.Enabled = false;
            this.comboBox_schoolid.FormattingEnabled = true;
            this.comboBox_schoolid.Location = new System.Drawing.Point(66, 23);
            this.comboBox_schoolid.Name = "comboBox_schoolid";
            this.comboBox_schoolid.Size = new System.Drawing.Size(100, 20);
            this.comboBox_schoolid.TabIndex = 10;
            this.comboBox_schoolid.SelectedIndexChanged += new System.EventHandler(this.comboBox_schoolid_SelectedIndexChanged);
            // 
            // comboBox_lessonIndex
            // 
            this.comboBox_lessonIndex.FormattingEnabled = true;
            this.comboBox_lessonIndex.Location = new System.Drawing.Point(65, 133);
            this.comboBox_lessonIndex.Name = "comboBox_lessonIndex";
            this.comboBox_lessonIndex.Size = new System.Drawing.Size(100, 20);
            this.comboBox_lessonIndex.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(18, 134);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(17, 12);
            this.label6.TabIndex = 8;
            this.label6.Text = "节";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(185, 84);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 7;
            this.label5.Text = "密码";
            // 
            // textBox_pwd
            // 
            this.textBox_pwd.Location = new System.Drawing.Point(249, 78);
            this.textBox_pwd.Name = "textBox_pwd";
            this.textBox_pwd.Size = new System.Drawing.Size(100, 21);
            this.textBox_pwd.TabIndex = 6;
            // 
            // textBox_user
            // 
            this.textBox_user.Location = new System.Drawing.Point(65, 78);
            this.textBox_user.Name = "textBox_user";
            this.textBox_user.Size = new System.Drawing.Size(100, 21);
            this.textBox_user.TabIndex = 5;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(18, 81);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(29, 12);
            this.label4.TabIndex = 2;
            this.label4.Text = "账号";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(185, 26);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 1;
            this.label3.Text = "教室ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(18, 26);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(41, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "学校ID";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.comboBox_ip);
            this.tabPage1.Controls.Add(this.textBoxLog);
            this.tabPage1.Controls.Add(this.button_reward);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.button_hondover);
            this.tabPage1.Controls.Add(this.button_handover_0);
            this.tabPage1.Controls.Add(this.button_handon);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(740, 400);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "测试";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // comboBox_ip
            // 
            this.comboBox_ip.FormattingEnabled = true;
            this.comboBox_ip.Location = new System.Drawing.Point(130, 17);
            this.comboBox_ip.Name = "comboBox_ip";
            this.comboBox_ip.Size = new System.Drawing.Size(156, 20);
            this.comboBox_ip.TabIndex = 7;
            // 
            // textBoxLog
            // 
            this.textBoxLog.Location = new System.Drawing.Point(18, 191);
            this.textBoxLog.Multiline = true;
            this.textBoxLog.Name = "textBoxLog";
            this.textBoxLog.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxLog.Size = new System.Drawing.Size(709, 199);
            this.textBoxLog.TabIndex = 6;
            // 
            // button_reward
            // 
            this.button_reward.Location = new System.Drawing.Point(358, 47);
            this.button_reward.Name = "button_reward";
            this.button_reward.Size = new System.Drawing.Size(95, 20);
            this.button_reward.TabIndex = 5;
            this.button_reward.Text = "奖励";
            this.button_reward.UseVisualStyleBackColor = true;
            this.button_reward.Click += new System.EventHandler(this.button_reward_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(23, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(53, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "IP地址：";
            // 
            // button_hondover
            // 
            this.button_hondover.Location = new System.Drawing.Point(250, 45);
            this.button_hondover.Name = "button_hondover";
            this.button_hondover.Size = new System.Drawing.Size(82, 22);
            this.button_hondover.TabIndex = 2;
            this.button_hondover.Text = "关闭点名button3";
            this.button_hondover.UseVisualStyleBackColor = true;
            this.button_hondover.Click += new System.EventHandler(this.button_hondover_Click);
            // 
            // button_handover_0
            // 
            this.button_handover_0.Location = new System.Drawing.Point(148, 46);
            this.button_handover_0.Name = "button_handover_0";
            this.button_handover_0.Size = new System.Drawing.Size(68, 21);
            this.button_handover_0.TabIndex = 1;
            this.button_handover_0.Text = "随机点名button2";
            this.button_handover_0.UseVisualStyleBackColor = true;
            this.button_handover_0.Click += new System.EventHandler(this.button_handover_0_Click);
            // 
            // button_handon
            // 
            this.button_handon.Location = new System.Drawing.Point(44, 45);
            this.button_handon.Name = "button_handon";
            this.button_handon.Size = new System.Drawing.Size(75, 23);
            this.button_handon.TabIndex = 0;
            this.button_handon.Text = "点名";
            this.button_handon.UseVisualStyleBackColor = true;
            this.button_handon.Click += new System.EventHandler(this.button_handon_Click);
            // 
            // FormTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(763, 450);
            this.Controls.Add(this.tabControl_main);
            this.MaximizeBox = false;
            this.Name = "FormTest";
            this.Text = "如e小助手---数据模拟生成器";
            this.tabControl_main.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl_main;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox textBox_user;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button_login;
        private System.Windows.Forms.Label label_LessonID;
        private System.Windows.Forms.ComboBox comboBox_roomid;
        private System.Windows.Forms.ComboBox comboBox_schoolid;
        private System.Windows.Forms.ComboBox comboBox_lessonIndex;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox textBox_pwd;
        private System.Windows.Forms.TextBox textBox_classname;
        private System.Windows.Forms.TextBox textBox_lessonid;
        private System.Windows.Forms.Button button_getlesson;
        private System.Windows.Forms.TextBox textBox_name;
        private System.Windows.Forms.TextBox textBox_coursename;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button_CompetitivePPT;
        private System.Windows.Forms.Button button_xitiPPT;
        private System.Windows.Forms.Button button_Competitive;
        private System.Windows.Forms.Button button_xiti;
        private System.Windows.Forms.Button button_ppt;
        private System.Windows.Forms.Button button_callname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button_hondover;
        private System.Windows.Forms.Button button_handover_0;
        private System.Windows.Forms.Button button_handon;
        private System.Windows.Forms.Button button_reward;
        private System.Windows.Forms.TextBox textBoxLog;
        private System.Windows.Forms.ComboBox comboBox_ip;
    }
}

