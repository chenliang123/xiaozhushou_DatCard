﻿namespace RueHelper
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            //this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label_Wr = new System.Windows.Forms.Label();
            this.label_Rr = new System.Windows.Forms.Label();
            this.label_Dr = new System.Windows.Forms.Label();
            this.label_Cr = new System.Windows.Forms.Label();
            this.label_Br = new System.Windows.Forms.Label();
            this.label_Ar = new System.Windows.Forms.Label();
            this.pictureBox_W = new System.Windows.Forms.PictureBox();
            this.pictureBox_R = new System.Windows.Forms.PictureBox();
            this.pictureBox_D = new System.Windows.Forms.PictureBox();
            this.pictureBox_C = new System.Windows.Forms.PictureBox();
            this.pictureBox_B = new System.Windows.Forms.PictureBox();
            this.pictureBox_A = new System.Windows.Forms.PictureBox();
            this.label_W = new System.Windows.Forms.Label();
            this.label_R = new System.Windows.Forms.Label();
            this.label_D = new System.Windows.Forms.Label();
            this.label_C = new System.Windows.Forms.Label();
            this.label_B = new System.Windows.Forms.Label();
            this.label_A = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label_top3_3 = new System.Windows.Forms.Label();
            this.label_top3_2 = new System.Windows.Forms.Label();
            this.label_top3_1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            //((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_W)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_R)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_D)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_C)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_B)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_A)).BeginInit();
            this.panel3.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(242)))), ((int)(((byte)(240)))));
            this.panel1.Location = new System.Drawing.Point(12, 116);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(539, 70);
            this.panel1.TabIndex = 6;
            this.panel1.Click += new System.EventHandler(this.panel1_Click);
            this.panel1.DoubleClick += new System.EventHandler(this.panel1_DoubleClick);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox4.Image = global::RueHelper.Properties.Resources.close_btn;
            this.pictureBox4.Location = new System.Drawing.Point(621, 362);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(26, 26);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox4.TabIndex = 3;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.pictureBox3.Image = global::RueHelper.Properties.Resources.min_btn;
            this.pictureBox3.Location = new System.Drawing.Point(585, 362);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(26, 26);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 2;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // webBrowser1
            // 
            this.webBrowser1.Location = new System.Drawing.Point(0, 80);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(129, 86);
            this.webBrowser1.TabIndex = 5;
            // 
            // pictureBox2
            // 
            //this.pictureBox2.BackColor = System.Drawing.Color.Transparent;
            //this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            //this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            //this.pictureBox2.Location = new System.Drawing.Point(0, 80);
            //this.pictureBox2.Name = "pictureBox2";
            //this.pictureBox2.Size = new System.Drawing.Size(670, 320);
            //this.pictureBox2.TabIndex = 1;
            //this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.White;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.pictureBox1.Image = global::RueHelper.Properties.Resources.logo;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(670, 80);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(242)))), ((int)(((byte)(240)))));
            this.panel2.Controls.Add(this.label_Wr);
            this.panel2.Controls.Add(this.label_Rr);
            this.panel2.Controls.Add(this.label_Dr);
            this.panel2.Controls.Add(this.label_Cr);
            this.panel2.Controls.Add(this.label_Br);
            this.panel2.Controls.Add(this.label_Ar);
            this.panel2.Controls.Add(this.pictureBox_W);
            this.panel2.Controls.Add(this.pictureBox_R);
            this.panel2.Controls.Add(this.pictureBox_D);
            this.panel2.Controls.Add(this.pictureBox_C);
            this.panel2.Controls.Add(this.pictureBox_B);
            this.panel2.Controls.Add(this.pictureBox_A);
            this.panel2.Controls.Add(this.label_W);
            this.panel2.Controls.Add(this.label_R);
            this.panel2.Controls.Add(this.label_D);
            this.panel2.Controls.Add(this.label_C);
            this.panel2.Controls.Add(this.label_B);
            this.panel2.Controls.Add(this.label_A);
            this.panel2.Location = new System.Drawing.Point(12, 210);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(539, 79);
            this.panel2.TabIndex = 7;
            this.panel2.DoubleClick += new System.EventHandler(this.panel2_DoubleClick);
            // 
            // label_Wr
            // 
            this.label_Wr.AutoSize = true;
            this.label_Wr.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_Wr.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label_Wr.Location = new System.Drawing.Point(416, 15);
            this.label_Wr.Name = "label_Wr";
            this.label_Wr.Size = new System.Drawing.Size(26, 21);
            this.label_Wr.TabIndex = 17;
            this.label_Wr.Text = "人";
            // 
            // label_Rr
            // 
            this.label_Rr.AutoSize = true;
            this.label_Rr.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_Rr.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label_Rr.Location = new System.Drawing.Point(333, 15);
            this.label_Rr.Name = "label_Rr";
            this.label_Rr.Size = new System.Drawing.Size(26, 21);
            this.label_Rr.TabIndex = 16;
            this.label_Rr.Text = "人";
            // 
            // label_Dr
            // 
            this.label_Dr.AutoSize = true;
            this.label_Dr.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_Dr.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label_Dr.Location = new System.Drawing.Point(266, 15);
            this.label_Dr.Name = "label_Dr";
            this.label_Dr.Size = new System.Drawing.Size(26, 21);
            this.label_Dr.TabIndex = 15;
            this.label_Dr.Text = "人";
            // 
            // label_Cr
            // 
            this.label_Cr.AutoSize = true;
            this.label_Cr.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_Cr.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label_Cr.Location = new System.Drawing.Point(138, 15);
            this.label_Cr.Name = "label_Cr";
            this.label_Cr.Size = new System.Drawing.Size(26, 21);
            this.label_Cr.TabIndex = 14;
            this.label_Cr.Text = "人";
            // 
            // label_Br
            // 
            this.label_Br.AutoSize = true;
            this.label_Br.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_Br.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label_Br.Location = new System.Drawing.Point(198, 15);
            this.label_Br.Name = "label_Br";
            this.label_Br.Size = new System.Drawing.Size(26, 21);
            this.label_Br.TabIndex = 13;
            this.label_Br.Text = "人";
            // 
            // label_Ar
            // 
            this.label_Ar.AutoSize = true;
            this.label_Ar.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_Ar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label_Ar.Location = new System.Drawing.Point(38, 15);
            this.label_Ar.Name = "label_Ar";
            this.label_Ar.Size = new System.Drawing.Size(26, 21);
            this.label_Ar.TabIndex = 12;
            this.label_Ar.Text = "人";
            // 
            // pictureBox_W
            // 
            this.pictureBox_W.Location = new System.Drawing.Point(428, 39);
            this.pictureBox_W.Name = "pictureBox_W";
            this.pictureBox_W.Size = new System.Drawing.Size(46, 25);
            this.pictureBox_W.TabIndex = 11;
            this.pictureBox_W.TabStop = false;
            // 
            // pictureBox_R
            // 
            this.pictureBox_R.Location = new System.Drawing.Point(353, 39);
            this.pictureBox_R.Name = "pictureBox_R";
            this.pictureBox_R.Size = new System.Drawing.Size(46, 25);
            this.pictureBox_R.TabIndex = 10;
            this.pictureBox_R.TabStop = false;
            // 
            // pictureBox_D
            // 
            this.pictureBox_D.Location = new System.Drawing.Point(279, 39);
            this.pictureBox_D.Name = "pictureBox_D";
            this.pictureBox_D.Size = new System.Drawing.Size(46, 25);
            this.pictureBox_D.TabIndex = 9;
            this.pictureBox_D.TabStop = false;
            // 
            // pictureBox_C
            // 
            this.pictureBox_C.Location = new System.Drawing.Point(196, 39);
            this.pictureBox_C.Name = "pictureBox_C";
            this.pictureBox_C.Size = new System.Drawing.Size(46, 25);
            this.pictureBox_C.TabIndex = 8;
            this.pictureBox_C.TabStop = false;
            // 
            // pictureBox_B
            // 
            this.pictureBox_B.Location = new System.Drawing.Point(122, 39);
            this.pictureBox_B.Name = "pictureBox_B";
            this.pictureBox_B.Size = new System.Drawing.Size(46, 25);
            this.pictureBox_B.TabIndex = 7;
            this.pictureBox_B.TabStop = false;
            // 
            // pictureBox_A
            // 
            this.pictureBox_A.Location = new System.Drawing.Point(32, 39);
            this.pictureBox_A.Name = "pictureBox_A";
            this.pictureBox_A.Size = new System.Drawing.Size(46, 25);
            this.pictureBox_A.TabIndex = 6;
            this.pictureBox_A.TabStop = false;
            // 
            // label_W
            // 
            this.label_W.AutoSize = true;
            this.label_W.Font = new System.Drawing.Font("微软雅黑", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_W.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label_W.Location = new System.Drawing.Point(381, 0);
            this.label_W.Name = "label_W";
            this.label_W.Size = new System.Drawing.Size(31, 30);
            this.label_W.TabIndex = 5;
            this.label_W.Text = "✘";
            // 
            // label_R
            // 
            this.label_R.AutoSize = true;
            this.label_R.Font = new System.Drawing.Font("微软雅黑", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_R.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label_R.Location = new System.Drawing.Point(301, 0);
            this.label_R.Name = "label_R";
            this.label_R.Size = new System.Drawing.Size(31, 30);
            this.label_R.TabIndex = 4;
            this.label_R.Text = "✔";
            // 
            // label_D
            // 
            this.label_D.AutoSize = true;
            this.label_D.Font = new System.Drawing.Font("微软雅黑", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_D.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label_D.Location = new System.Drawing.Point(230, 0);
            this.label_D.Name = "label_D";
            this.label_D.Size = new System.Drawing.Size(30, 30);
            this.label_D.TabIndex = 3;
            this.label_D.Text = "D";
            // 
            // label_C
            // 
            this.label_C.AutoSize = true;
            this.label_C.Font = new System.Drawing.Font("微软雅黑", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_C.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label_C.Location = new System.Drawing.Point(172, 0);
            this.label_C.Name = "label_C";
            this.label_C.Size = new System.Drawing.Size(28, 30);
            this.label_C.TabIndex = 2;
            this.label_C.Text = "C";
            // 
            // label_B
            // 
            this.label_B.AutoSize = true;
            this.label_B.Font = new System.Drawing.Font("微软雅黑", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_B.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label_B.Location = new System.Drawing.Point(105, 0);
            this.label_B.Name = "label_B";
            this.label_B.Size = new System.Drawing.Size(27, 30);
            this.label_B.TabIndex = 1;
            this.label_B.Text = "B";
            // 
            // label_A
            // 
            this.label_A.AutoSize = true;
            this.label_A.Font = new System.Drawing.Font("微软雅黑", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_A.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.label_A.Location = new System.Drawing.Point(15, 0);
            this.label_A.Name = "label_A";
            this.label_A.Size = new System.Drawing.Size(28, 30);
            this.label_A.TabIndex = 0;
            this.label_A.Text = "A";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(243)))), ((int)(((byte)(242)))), ((int)(((byte)(240)))));
            this.panel3.Controls.Add(this.label_top3_3);
            this.panel3.Controls.Add(this.label_top3_2);
            this.panel3.Controls.Add(this.label_top3_1);
            this.panel3.Location = new System.Drawing.Point(12, 311);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(474, 77);
            this.panel3.TabIndex = 8;
            // 
            // label_top3_3
            // 
            this.label_top3_3.AutoSize = true;
            this.label_top3_3.Font = new System.Drawing.Font("微软雅黑", 25F, System.Drawing.FontStyle.Bold);
            this.label_top3_3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(187)))), ((int)(((byte)(98)))));
            this.label_top3_3.Location = new System.Drawing.Point(330, 25);
            this.label_top3_3.Name = "label_top3_3";
            this.label_top3_3.Size = new System.Drawing.Size(136, 45);
            this.label_top3_3.TabIndex = 2;
            this.label_top3_3.Text = "top3_3";
            // 
            // label_top3_2
            // 
            this.label_top3_2.AutoSize = true;
            this.label_top3_2.Font = new System.Drawing.Font("微软雅黑", 24.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label_top3_2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(187)))), ((int)(((byte)(98)))));
            this.label_top3_2.Location = new System.Drawing.Point(171, 25);
            this.label_top3_2.Name = "label_top3_2";
            this.label_top3_2.Size = new System.Drawing.Size(133, 44);
            this.label_top3_2.TabIndex = 1;
            this.label_top3_2.Text = "top3_2";
            // 
            // label_top3_1
            // 
            this.label_top3_1.AutoSize = true;
            this.label_top3_1.Font = new System.Drawing.Font("微软雅黑", 25F, System.Drawing.FontStyle.Bold);
            this.label_top3_1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(187)))), ((int)(((byte)(98)))));
            this.label_top3_1.Location = new System.Drawing.Point(26, 25);
            this.label_top3_1.Name = "label_top3_1";
            this.label_top3_1.Size = new System.Drawing.Size(136, 45);
            this.label_top3_1.TabIndex = 0;
            this.label_top3_1.Text = "top3_1";
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(670, 400);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.webBrowser1);
            //this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form2_FormClosing);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            //((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_W)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_R)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_D)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_C)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_B)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_A)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        //private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label_top3_3;
        private System.Windows.Forms.Label label_top3_2;
        private System.Windows.Forms.Label label_top3_1;
        private System.Windows.Forms.Label label_W;
        private System.Windows.Forms.Label label_R;
        private System.Windows.Forms.Label label_D;
        private System.Windows.Forms.Label label_C;
        private System.Windows.Forms.Label label_B;
        private System.Windows.Forms.Label label_A;
        private System.Windows.Forms.PictureBox pictureBox_W;
        private System.Windows.Forms.PictureBox pictureBox_R;
        private System.Windows.Forms.PictureBox pictureBox_D;
        private System.Windows.Forms.PictureBox pictureBox_C;
        private System.Windows.Forms.PictureBox pictureBox_B;
        private System.Windows.Forms.PictureBox pictureBox_A;
        private System.Windows.Forms.Label label_Wr;
        private System.Windows.Forms.Label label_Rr;
        private System.Windows.Forms.Label label_Dr;
        private System.Windows.Forms.Label label_Cr;
        private System.Windows.Forms.Label label_Br;
        private System.Windows.Forms.Label label_Ar;


    }
}