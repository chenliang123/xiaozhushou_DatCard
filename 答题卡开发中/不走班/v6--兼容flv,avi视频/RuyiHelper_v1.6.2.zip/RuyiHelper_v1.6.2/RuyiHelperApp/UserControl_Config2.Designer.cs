﻿namespace RueHelper
{
    partial class UserControl_Config2
    {
        /// <summary> 
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region 组件设计器生成的代码

        /// <summary> 
        /// 设计器支持所需的方法 - 不要
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button_pptopen = new System.Windows.Forms.Button();
            this.button_pptnext = new System.Windows.Forms.Button();
            this.button_pptmin = new System.Windows.Forms.Button();
            this.button_pptmax = new System.Windows.Forms.Button();
            this.button_pptclose = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.Location = new System.Drawing.Point(16, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(23, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "1) ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.Location = new System.Drawing.Point(16, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(27, 17);
            this.label2.TabIndex = 1;
            this.label2.Text = "2）";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label3.Location = new System.Drawing.Point(16, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(27, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "3）";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label4.Location = new System.Drawing.Point(16, 144);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(19, 17);
            this.label4.TabIndex = 3;
            this.label4.Text = "4)";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label5.Location = new System.Drawing.Point(16, 191);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(32, 17);
            this.label5.TabIndex = 4;
            this.label5.Text = "注：";
            // 
            // button_pptopen
            // 
            this.button_pptopen.Location = new System.Drawing.Point(28, 230);
            this.button_pptopen.Name = "button_pptopen";
            this.button_pptopen.Size = new System.Drawing.Size(75, 23);
            this.button_pptopen.TabIndex = 5;
            this.button_pptopen.Text = "打开PPT";
            this.button_pptopen.UseVisualStyleBackColor = true;
            this.button_pptopen.Visible = false;
            this.button_pptopen.Click += new System.EventHandler(this.button_pptopen_Click);
            // 
            // button_pptnext
            // 
            this.button_pptnext.Location = new System.Drawing.Point(109, 230);
            this.button_pptnext.Name = "button_pptnext";
            this.button_pptnext.Size = new System.Drawing.Size(75, 23);
            this.button_pptnext.TabIndex = 6;
            this.button_pptnext.Text = "下一页";
            this.button_pptnext.UseVisualStyleBackColor = true;
            this.button_pptnext.Visible = false;
            this.button_pptnext.Click += new System.EventHandler(this.button_pptnext_Click);
            // 
            // button_pptmin
            // 
            this.button_pptmin.Location = new System.Drawing.Point(190, 230);
            this.button_pptmin.Name = "button_pptmin";
            this.button_pptmin.Size = new System.Drawing.Size(75, 23);
            this.button_pptmin.TabIndex = 7;
            this.button_pptmin.Text = "最小化";
            this.button_pptmin.UseVisualStyleBackColor = true;
            this.button_pptmin.Visible = false;
            this.button_pptmin.Click += new System.EventHandler(this.button_pptmin_Click);
            // 
            // button_pptmax
            // 
            this.button_pptmax.Location = new System.Drawing.Point(271, 230);
            this.button_pptmax.Name = "button_pptmax";
            this.button_pptmax.Size = new System.Drawing.Size(75, 23);
            this.button_pptmax.TabIndex = 8;
            this.button_pptmax.Text = "最大化";
            this.button_pptmax.UseVisualStyleBackColor = true;
            this.button_pptmax.Visible = false;
            this.button_pptmax.Click += new System.EventHandler(this.button_pptmax_Click);
            // 
            // button_pptclose
            // 
            this.button_pptclose.Location = new System.Drawing.Point(154, 259);
            this.button_pptclose.Name = "button_pptclose";
            this.button_pptclose.Size = new System.Drawing.Size(75, 23);
            this.button_pptclose.TabIndex = 9;
            this.button_pptclose.Text = "关闭";
            this.button_pptclose.UseVisualStyleBackColor = true;
            this.button_pptclose.Visible = false;
            this.button_pptclose.Click += new System.EventHandler(this.button_pptclose_Click);
            // 
            // UserControl_Config2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.Controls.Add(this.button_pptclose);
            this.Controls.Add(this.button_pptmax);
            this.Controls.Add(this.button_pptmin);
            this.Controls.Add(this.button_pptnext);
            this.Controls.Add(this.button_pptopen);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "UserControl_Config2";
            this.Size = new System.Drawing.Size(400, 330);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button button_pptopen;
        private System.Windows.Forms.Button button_pptnext;
        private System.Windows.Forms.Button button_pptmin;
        private System.Windows.Forms.Button button_pptmax;
        private System.Windows.Forms.Button button_pptclose;
    }
}
