﻿namespace RueHelper
{
    partial class FormAward
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormAward));
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label_name3 = new System.Windows.Forms.Label();
            this.label_name2 = new System.Windows.Forms.Label();
            this.label_name1 = new System.Windows.Forms.Label();
            this.label_title3 = new System.Windows.Forms.Label();
            this.label_title2 = new System.Windows.Forms.Label();
            this.label_title1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox2.Image = global::RueHelper.Properties.Resources.star1_3;
            this.pictureBox2.Location = new System.Drawing.Point(156, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(391, 200);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Visible = false;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("微软雅黑", 42F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(176)))), ((int)(((byte)(102)))));
            this.label2.Image = global::RueHelper.Properties.Resources.star1_name;
            this.label2.Location = new System.Drawing.Point(93, 196);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(510, 245);
            this.label2.TabIndex = 3;
            this.label2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.label2.Visible = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label_name3);
            this.panel1.Controls.Add(this.label_name2);
            this.panel1.Controls.Add(this.label_name1);
            this.panel1.Controls.Add(this.label_title3);
            this.panel1.Controls.Add(this.label_title2);
            this.panel1.Controls.Add(this.label_title1);
            this.panel1.Location = new System.Drawing.Point(12, 377);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(245, 162);
            this.panel1.TabIndex = 4;
            this.panel1.Visible = false;
            // 
            // label_name3
            // 
            this.label_name3.AutoSize = true;
            this.label_name3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold);
            this.label_name3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(176)))), ((int)(((byte)(102)))));
            this.label_name3.Location = new System.Drawing.Point(123, 126);
            this.label_name3.Name = "label_name3";
            this.label_name3.Size = new System.Drawing.Size(110, 22);
            this.label_name3.TabIndex = 5;
            this.label_name3.Text = "label_name3";
            // 
            // label_name2
            // 
            this.label_name2.AutoSize = true;
            this.label_name2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold);
            this.label_name2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(176)))), ((int)(((byte)(102)))));
            this.label_name2.Location = new System.Drawing.Point(123, 95);
            this.label_name2.Name = "label_name2";
            this.label_name2.Size = new System.Drawing.Size(110, 22);
            this.label_name2.TabIndex = 4;
            this.label_name2.Text = "label_name2";
            // 
            // label_name1
            // 
            this.label_name1.AutoSize = true;
            this.label_name1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold);
            this.label_name1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(176)))), ((int)(((byte)(102)))));
            this.label_name1.Location = new System.Drawing.Point(123, 62);
            this.label_name1.Name = "label_name1";
            this.label_name1.Size = new System.Drawing.Size(110, 22);
            this.label_name1.TabIndex = 3;
            this.label_name1.Text = "label_name1";
            // 
            // label_title3
            // 
            this.label_title3.AutoSize = true;
            this.label_title3.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold);
            this.label_title3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(176)))), ((int)(((byte)(102)))));
            this.label_title3.Location = new System.Drawing.Point(7, 126);
            this.label_title3.Name = "label_title3";
            this.label_title3.Size = new System.Drawing.Size(99, 22);
            this.label_title3.TabIndex = 2;
            this.label_title3.Text = "label_title3";
            // 
            // label_title2
            // 
            this.label_title2.AutoSize = true;
            this.label_title2.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold);
            this.label_title2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(176)))), ((int)(((byte)(102)))));
            this.label_title2.Location = new System.Drawing.Point(7, 95);
            this.label_title2.Name = "label_title2";
            this.label_title2.Size = new System.Drawing.Size(99, 22);
            this.label_title2.TabIndex = 1;
            this.label_title2.Text = "label_title2";
            // 
            // label_title1
            // 
            this.label_title1.AutoSize = true;
            this.label_title1.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold);
            this.label_title1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(176)))), ((int)(((byte)(102)))));
            this.label_title1.Location = new System.Drawing.Point(7, 62);
            this.label_title1.Name = "label_title1";
            this.label_title1.Size = new System.Drawing.Size(99, 22);
            this.label_title1.TabIndex = 0;
            this.label_title1.Text = "label_title1";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::RueHelper.Properties.Resources.jiangli;
            this.pictureBox1.Location = new System.Drawing.Point(139, 196);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(397, 189);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox1.TabIndex = 6;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Visible = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 30F);
            this.label1.Location = new System.Drawing.Point(14, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(219, 52);
            this.label1.TabIndex = 7;
            this.label1.Text = "获 得 奖 励";
            // 
            // FormAward
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 551);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FormAward";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form10";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label_name3;
        private System.Windows.Forms.Label label_name2;
        private System.Windows.Forms.Label label_name1;
        private System.Windows.Forms.Label label_title3;
        private System.Windows.Forms.Label label_title2;
        private System.Windows.Forms.Label label_title1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
    }
}